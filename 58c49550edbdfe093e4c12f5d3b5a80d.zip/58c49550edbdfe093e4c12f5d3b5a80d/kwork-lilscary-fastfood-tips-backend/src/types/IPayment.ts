export type IPayment = {
    id: string,
    status: string,
    isPaid: boolean,
    flag: string
}